package myCart.learn.dao;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import myCart.user.Entity.Product;

public class ProductDao {

	private SessionFactory factory;

	public ProductDao(SessionFactory factory) {
		this.factory = factory;
	}
	
	public boolean saveProduct(Product product) {
		boolean flag=false;
		try {
		Session session=this.factory.openSession();
		Transaction tx=session.beginTransaction();
		 session.save(product);
		tx.commit();
		session.close();
		flag=true;
	
	}catch(Exception e) {
		e.printStackTrace();
		flag=false;
	}
		return flag;
}
	
}
